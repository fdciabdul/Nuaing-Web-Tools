<?php

// just a transient page...

header("Location:web");