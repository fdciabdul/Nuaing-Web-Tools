                <div id="footer" <?php if(isset($num_doc_found) && $num_doc_found > 0) echo 'style="position: relative;"' ?>>
                    <div id="links">
                        <a href="http://cs.ipb.ac.id">Computer Science IPB</a>
                        |
                        <a href="./">Lafzi Web</a>
                        |
                        <a href="/desktop">Lafzi Desktop</a>
                        |
                        <a href="https://play.google.com/store/apps/details?id=org.lafzi.lafzi&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1">Lafzi Android</a>
                        |
                        <a href="about.php">Tentang Lafzi</a>
                        <?php /*|
                        <a href="http://abrari.wordpress.com/category/skripsi" target="_blank">Development Blog</a>
                        |
                        <a href="http://code.google.com/p/pencarian-fonetik-quran" target="_blank">Repositori Source Code</a>
                        */ ?>
                    </div>
                    <div id="copyright">
                        Copyright &copy 2012-<?php echo date("Y"); ?> Computer Science IPB
                    </div>
                </div>                
                
