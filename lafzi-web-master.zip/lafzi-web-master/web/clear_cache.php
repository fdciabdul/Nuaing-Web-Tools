<?php

if (exec("rm ../cache/*") == "") echo "Cache dihapus";

?>
