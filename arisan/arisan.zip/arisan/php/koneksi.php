<?php
    date_default_timezone_set('Asia/Jakarta');
    $conn = new mysqli("localhost","root","","arisan");
  