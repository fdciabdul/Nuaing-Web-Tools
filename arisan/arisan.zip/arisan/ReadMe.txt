Fb : http://fb.me/rizal.ofdraw
Blog : codinger-mini.blogspot.com

How to install ..
	1. Ekstrak .zip, pindahkan folder /arisan ke /htdocs atau /www atau folder root
	2. nyalakan webserver.
	3. buka phpmyadmin
	4. buat database baru -> klik database yang baru di buat kemudian Pilih import. silahkan import file arisan.sql
	5. kembali ke folder arisan. buka file /arisan/php/koneksi.php, sesuaikan dengan konfigurasi database agan
	6. save, lalu buka di browser http://localhost/arisan atau nama folder agan
	7. Selesai.

untuk pertanyaan kirim ke fb ada tapi add dulu biar messagenya masuk :D
